import React from 'react'

const Institute = () => {
  return (
    <div>Institute</div>
  )
}

export default Institute