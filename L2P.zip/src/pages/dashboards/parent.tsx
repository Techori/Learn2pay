import React from 'react'

const Parent = () => {
  return (
    <div>Parent</div>
  )
}

export default Parent