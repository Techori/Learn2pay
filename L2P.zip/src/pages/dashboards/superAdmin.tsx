import React from "react";

const SuperAdmin = () => {
  return <div>SuperAdmin</div>;
};

export default SuperAdmin;
