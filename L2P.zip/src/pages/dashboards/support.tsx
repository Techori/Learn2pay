import React from "react";

const Support = () => {
  return <div>Support</div>;
};

export default Support;
