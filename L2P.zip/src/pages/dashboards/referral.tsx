import React from 'react'

const Referral = () => {
  return (
    <div>Referral</div>
  )
}

export default Referral
